package com.company;

public class Gerente extends Vendedor{
    DAO dao = new DAO();
    public void CadastrarVendedor(String id,  String nome)
    {
        String ArquivoMontado = id+";"+nome;
        dao.EscreveArquivo("Vendedor.txt", ArquivoMontado);
    }
}
