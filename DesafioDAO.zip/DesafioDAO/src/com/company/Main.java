package com.company;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args) throws IOException {
        // write your code
        Scanner entrada = new Scanner(System.in);
        String decisao = "";
        while (!decisao.equals("5")) {
            System.out.println("O que deseja fazer?");
            System.out.println("1 - Entrar como Gerente");
            System.out.println("2 - Entrar como Vendedor");
            System.out.println("3 - Pesquisar");
            System.out.println("4 - Sair");
            System.out.print("Escolha: ");
            decisao = entrada.next();
            switch (decisao) {
                case "1":
                    String escolhaGerente = "";
                    Gerente gerente = new Gerente();
                    while (!escolhaGerente.equals("5")) {
                        System.out.println("1 - Cadastar vendedor");
                        System.out.println("2 - Cadastrar produto");
                        System.out.println("3 - Cadastrar pedido");
                        System.out.println("4 - Cadastrar cliente");
                        System.out.println("5 - Sair");
                        System.out.print("Escolha: ");
                        escolhaGerente = entrada.next();
                        switch (escolhaGerente) {
                            case "1":
                                System.out.println("Digite o nome do vendedor");
                                String nomeFuncionario = entrada.next();
                                System.out.println("Digite o ID do vendedor");
                                String IDFuncionario = entrada.next();
                                gerente.CadastrarVendedor(IDFuncionario, nomeFuncionario);
                                System.out.println("Vendedor cadastrado com sucesso");
                                break;
                            case "2":
                                System.out.println("Digite o nome do produto");
                                String nomeProduto = entrada.next();
                                System.out.println("ID do produto");
                                String idProduto = entrada.nextLine();
                                gerente.CadastrarProdutos(idProduto, nomeProduto);
                                break;
                            case "3":
                                System.out.println("Digite o ID do pedido");
                                String idPedido = entrada.next();
                                System.out.println("Digite o ID do produto");
                                String idProdutoPed = entrada.next();
                                System.out.println("Digite o ID do vendedor");
                                String idVendedor = entrada.next();
                                System.out.println("Digite o ID do cliente");
                                String idCliente = entrada.next();
                                gerente.CadastrarPedido(idProdutoPed, idVendedor, idPedido, idCliente);
                                System.out.println("Pedido cadastrado com sucesso");
                                break;
                            case "4":
                                System.out.println("Digite o nome do cliente");
                                String nomeCadCliente = entrada.next();
                                System.out.println("Digite o ID do cliente");
                                String idCadCliente = entrada.next();
                                gerente.CadastrarClientes(idCadCliente, nomeCadCliente);
                                break;
                            case "5":
                                break;
                        }
                    }
                    break;
                case "2":
                    Vendedor vendedor = new Vendedor();
                    String escolhaFuncionario = "";
                    while (!escolhaFuncionario.equals("4")) {
                        System.out.println("1 - Cadastrar produto");
                        System.out.println("2 - Cadastrar pedido");
                        System.out.println("3 - Cadastrar cliente");
                        System.out.println("4 - Sair");
                        System.out.print("Escolha: ");
                        escolhaFuncionario = entrada.next();
                        switch (escolhaFuncionario) {
                            case "1":
                                System.out.println("Digite o nome do produto");
                                String nomeProduto = entrada.next();
                                System.out.println("ID do produto");
                                String idProduto = entrada.next();
                                vendedor.CadastrarProdutos(idProduto, nomeProduto);
                                break;
                            case "2":
                                System.out.println("Digite o ID do pedido");
                                String idPedido = entrada.next();
                                System.out.println("Digite o ID do produto");
                                String idProdutoPed = entrada.next();
                                System.out.println("Digite o ID do vendedor");
                                String idVendedor = entrada.next();
                                System.out.println("Digite o ID do cliente");
                                String idCliente = entrada.next();
                                vendedor.CadastrarPedido(idProdutoPed, idVendedor, idPedido, idCliente);
                                System.out.println("Pedido cadastrado com sucesso");
                            case "3":
                                System.out.println("Digite o nome do cliente");
                                String nomeCadCliente = entrada.next();
                                System.out.println("Digite o ID do cliente");
                                String idCadCliente = entrada.next();
                                vendedor.CadastrarClientes(idCadCliente, nomeCadCliente);
                                break;
                            case "4":
                                break;
                        }
                    }
                case "3":
                    String escolhaPesquisar = "";
                    Vendedor vend = new Vendedor();
                    while (!escolhaPesquisar.equals("5")) {
                        System.out.println("O que deseja pesquisar?");
                        System.out.println("1 - Vendedores");
                        System.out.println("2 - Produtos");
                        System.out.println("3 - Cliente");
                        System.out.println("4 - Pedidos");
                        System.out.println("5 - Sair");
                        System.out.print("Escolha: ");
                        escolhaPesquisar = entrada.next();
                        switch (escolhaPesquisar) {
                            case "1":
                                vend.Pesquisar("Vendedor.txt", 1);
                                break;
                            case "2":
                                vend.Pesquisar("Produtos.txt", 1);
                                break;
                            case "3":
                                vend.Pesquisar("Clientes.txt", 1);
                                break;
                        }
                    }
            }
        }
    }
}
