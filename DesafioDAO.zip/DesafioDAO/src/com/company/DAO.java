package com.company;

import java.io.*;
import java.util.*;

public class DAO {
    public  List<String> LeArquivo(String Arquivo)
    {
        File arquivo = new File(Arquivo);
        List<String> Leitor = new ArrayList<String>();
        if (arquivo.exists()) {
            try {
                BufferedReader in = new BufferedReader(new FileReader(arquivo));
                String dados;
                while (in.ready()) {
                    dados = in.readLine();
                    Leitor.add(dados);
                }
                in.close();
            } catch (IOException e) {
                return Leitor;
            }
        }
        return Leitor;
    }
   public  void EscreveArquivo(String Arquivo, String texto )
   {
       try{
           List<String> Leitor = LeArquivo(Arquivo);
           FileWriter escritor=new FileWriter(Arquivo,true);
           BufferedWriter bw = new BufferedWriter(escritor);

           if (Leitor.size()==0)
           {
               bw.write(texto);
           }
           else
           {
               bw.newLine();
               bw.write(texto);
           }
           bw.close();
       }catch(Exception e){System.out.println(e);}
    }
    public void ApagarRegistro(String Arquivo, String id) throws IOException {
        List<String> Dados = LeArquivo(Arquivo);
        for(int n =0; n<= Dados.size();n++)
        {
            if (Dados.get(n) == id)
            {
                Dados.remove(n);
            }
        }
        FileWriter escritor=new FileWriter(Arquivo,true);
        BufferedWriter bw = new BufferedWriter(escritor);
    }
}



