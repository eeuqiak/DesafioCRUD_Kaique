package com.company;

import java.util.List;

public class VO
{
    DAO dao = new DAO();
    public void EscreveVendedor(String id, String nome)
    {
        String ArquivoMontado = id+";"+nome;
        dao.EscreveArquivo("Vendedor.txt", ArquivoMontado);
    }
    public void EscreveGerente(String id, String nome)
    {
        String ArquivoMontado = id+";"+nome;
        dao.EscreveArquivo("Gerente.txt", ArquivoMontado);
    }

}
