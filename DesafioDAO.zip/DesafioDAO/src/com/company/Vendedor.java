package com.company;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Vendedor
{
    String patch = "";
    DAO dao = new DAO();
    public void CadastrarProdutos(String id, String nome)
    {
            String TextoMontado = id+";"+nome;
            dao.EscreveArquivo("Produtos.txt", TextoMontado);
    }
    public void  CadastrarClientes(String id, String nome)
    {
        String TextoMontado = id+";" + nome;
        dao.EscreveArquivo("Clientes.txt",TextoMontado );
    }
    public void  CadastrarPedido(String idproduto,String idVendedor,String idCliente, String idPedido)
    {
        String TextoMontado = idproduto+";"+idVendedor+";"+idCliente+";"+idPedido;
        dao.EscreveArquivo("Pedidos.txt", TextoMontado);
    }
    public void Pesquisar(String Arquivo, int index)
    {
        List<String> Dados = dao.LeArquivo(Arquivo);

        for (int n = 0; n< Dados.size(); n++)
        {
            String[] vetor = Dados.get(n).split(";");
            System.out.println(vetor[index]);
        }
    }
}
